# ASHI-CORE v2.1.0 — consolidated audit, 8 November 2026

## Scope
This package consolidates **all tests executed in this conversation**, including EEGMMIDB exploratory analysis, original ASHI C EEG testing, sensory watchdog tests, matched baseline tests, C-MAPSS 4FD analysis, persistent alarms, and a final additional comparator benchmark. The EEGMMIDB NeuroCore-operator comparison used a *proxy operationalization*, **not authenticated original NeuroCore operators**.

## Strongest relevant comparison: NASA C-MAPSS
355 held-out engines across FD001–FD004, 354 calibration engines. ASHI kernel `ashicore_v210.c` compiled unchanged with `Kc=1.441`. Inputs are engineered log1p RMS multichannel deviations relative to regime-specific reference states fitted on calibration engines' first 25 cycles. The original kernel does not define this feature mapping.

Baseline thresholds are chosen from early calibration trajectories to match ASHI's *raw* alarm frequency on calibration data. No thresholds are tuned on test engines. Persistent alarm = at least 10 positives in the trailing 15 cycles. The first and last quarters of life are **proxies**; exact fault onset and healthy-state labels are unavailable.

| Detector | Early raw positive rate | Late persistent fraction |
|---|---:|---:|
| CUSUM | 6.995% | 94.520% |
| Fixed-level | 6.600% | 89.622% |
| ASHI original | 7.788% | 86.945% |
| Cumulative z | 7.940% | 84.080% |
| Rolling z (30) | 7.655% | 10.575% |
| EWMA z | 8.123% | 0.000% |

Paired engine-bootstrap 95% CI for ASHI minus CUSUM late persistence: **-9.34 to -5.91 percentage points**. For ASHI minus cumulative z: **+2.25 to +3.51 pp**. These intervals quantify resampling uncertainty on these held-out engines under the chosen experimental design, not generalizability to real engines.

## Verdict
**ASHI is not the best-performing method in this particular persistence benchmark.** CUSUM and fixed-level beat it on late persistence with comparable early raw positive rates. This is a reproducible empirical result, not a claim of universal superiority or inferiority. Higher late persistence alone is not fault-detection accuracy or prognostic lead time. CUSUM is a simplified experimental implementation; not a certified industrial product. The user-provided kernel is a causal upper-tail running statistical threshold; no machine control is tested.

## Reproduction
1. Extract original NASA `CMAPSSData.zip` from the user-provided dataset; copy `train_FD001.txt` through `train_FD004.txt` into `C_MAPSS/` or into the directory with the script.
2. `gcc -O3 -shared -fPIC -Dmain=ashi_original_main ashicore_v210.c -lm -o libashi.so`
3. Install numpy pandas scipy scikit-learn.
4. Run `python definitive_extra.py` from the folder containing the EDF-independent C-MAPSS files; the script derives all scores, thresholds, and tables.
5. See `definitive_protocol.json`, `definitive_per_engine.csv`, `definitive_by_fd.csv`, `definitive_paired_ci.csv`.

## Important restrictions
- Previous archives include their original scripts, data derivatives, and limitations, and are preserved **without retroactively rewriting the earlier reported results**.
- No verified labels of fault onset; no claim of actual failure-prediction horizon, independent false alarms/hour, or industrial qualification.
- No assertion of supremacy over modern commercial PHM systems or modern ML prognostic methods.
- Training/test partition is deterministic, per engine, but it is **one split**. No multi-seed independent validation.
- Dataset raw recordings are excluded from consolidated ZIP; retrieve them from the originally uploaded NASA archive.
- `definitive_extra.py` depends on the original C kernel and pre-extracted C-MAPSS text files.
