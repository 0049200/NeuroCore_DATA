import os,ctypes,json,time
import numpy as np,pandas as pd
from sklearn.cluster import KMeans
R=os.path.dirname(__file__); rng=np.random.default_rng(20261108)
class K(ctypes.Structure):
 _fields_=[('count',ctypes.c_long),('mean',ctypes.c_double),('m2',ctypes.c_double),('last_sigma',ctypes.c_double),('kc',ctypes.c_double),('trend_buffer',ctypes.c_double*10)]
lib=ctypes.CDLL(os.path.join(R,'libashi.so'));lib.ashi_kernel_init.argtypes=[ctypes.POINTER(K)];lib.ashi_kernel_compute_step.argtypes=[ctypes.POINTER(K),ctypes.c_double];lib.ashi_kernel_compute_step.restype=ctypes.c_int

def score(x):
 n=len(x);k=K();lib.ashi_kernel_init(ctypes.byref(k));ash=np.zeros(n);cum=np.zeros(n);roll=np.zeros(n);ew=np.zeros(n);cs=np.zeros(n);ph=np.zeros(n);mu=0.;m2=0.;ema=0.;ev=1e-6;acc=0.;minacc=0.
 for i,v in enumerate(x):
  if i>=5:
   cum[i]=(v-mu)/max(np.sqrt(m2/(i-1)),1e-4)
   prev=x[max(0,i-30):i];roll[i]=(v-prev.mean())/max(prev.std(ddof=1),1e-4)
   ew[i]=(v-ema)/max(np.sqrt(ev),1e-4)
  ash[i]=lib.ashi_kernel_compute_step(ctypes.byref(k),float(v))
  # one-sided positive CUSUM against a fixed initial reference
  if i==0:ref=float(v)
  if i<10:ref=ref+(v-ref)/(i+1)
  acc=max(0.,acc+v-ref-.025);cs[i]=acc
  d=v-mu;mu+=d/(i+1);m2+=d*(v-mu)
  if i==0:ema=v
  else:
   de=v-ema;ema=.1*v+.9*ema;ev=.1*de*de+.9*ev
 return {'ASHI_original':ash,'cumulative_z':cum,'rolling_z30':roll,'EWMA_z':ew,'CUSUM':cs,'fixed_level':x,'cumulative_mean':np.cumsum(x)/np.arange(1,n+1)}

def persistent(raw):return np.convolve(raw.astype(np.int8),np.ones(15,dtype=int),'full')[:len(raw)]>=10
records=[]; calibration=[]; diagnostics=[]
for fd in range(1,5):
 d=pd.read_csv(os.path.join(R,f'train_FD00{fd}.txt'),sep=r'\s+',header=None)
 ids=np.array(sorted(d[0].unique()));rng.shuffle(ids);cut=int(len(ids)*.5);cal_ids=set(ids[:cut]);test_ids=set(ids[cut:]);cal=d[d[0].isin(cal_ids)&(d[1]<=25)]
 sens=np.arange(5,26);std=cal[sens].std().values;sel=sens[std>1e-4]
 km=KMeans(n_clusters=1 if fd in (1,3) else 6,random_state=2026,n_init=5).fit(cal[[2,3,4]].values)
 d['reg']=km.predict(d[[2,3,4]].values);refs={}
 for reg in range(km.n_clusters):
  q=d[(d[0].isin(cal_ids))&(d[1]<=25)&(d.reg==reg)][sel].values
  if len(q)<20:q=cal[sel].values
  refs[reg]=(np.median(q,axis=0),np.maximum(np.std(q,axis=0),np.maximum(std[std>1e-4]*.05,1e-3)))
 cache={}
 for uid,g in d.groupby(0):
  a=g[sel].values;reg=g.reg.values.astype(int)
  zz=np.array([np.sqrt(np.mean(np.clip((v-refs[r][0])/refs[r][1],-15,15)**2)) for v,r in zip(a,reg)])
  cache[int(uid)]=score(np.log1p(zz))
 methods=['cumulative_z','rolling_z30','EWMA_z','CUSUM','fixed_level','cumulative_mean']
 # Calibrate to ASHI's raw early positive rate in calibration engines; no test data used
 target=np.mean([cache[int(uid)]['ASHI_original'][5:max(6,int(len(cache[int(uid)]['ASHI_original'])*.25))].mean() for uid in cal_ids])
 thresholds={}
 for method in methods:
  v=np.concatenate([cache[int(uid)][method][5:max(6,int(len(cache[int(uid)][method])*.25))] for uid in cal_ids]); thresholds[method]=float(np.quantile(v,1-target))
 for uid in test_ids:
  s=cache[int(uid)];n=len(s['ASHI_original']);early=slice(5,max(6,int(n*.25)));late=slice(int(n*.75),n)
  for method in ['ASHI_original']+methods:
   raw=s[method].astype(bool) if method=='ASHI_original' else s[method]>thresholds[method]
   p=persistent(raw);ix=np.flatnonzero(p & (np.arange(n)>=5));first=int(ix[0]) if len(ix) else None
   records.append(dict(fd=fd,engine=int(uid),method=method,n=n,early_raw=float(raw[early].mean()),late_raw=float(raw[late].mean()),early_persistent=float(p[early].mean()),late_persistent=float(p[late].mean()),final_persistent=int(p[-1]),ever_persistent=int(bool(len(ix))),first_persistent_cycle=first+1 if first is not None else np.nan,cycles_before_end=n-1-first if first is not None else np.nan))
 diagnostics.append(dict(fd=fd,calibration_engines=len(cal_ids),test_engines=len(test_ids),target_early_raw_rate=target,thresholds=thresholds))
 print('completed FD',fd,flush=True)
rec=pd.DataFrame(records);rec.to_csv(os.path.join(R,'definitive_per_engine.csv'),index=False)
summ=rec.groupby('method').agg(engines=('engine','count'),early_raw=('early_raw','mean'),late_raw=('late_raw','mean'),early_persistent=('early_persistent','mean'),late_persistent=('late_persistent','mean'),final_persistent=('final_persistent','mean'),ever_persistent=('ever_persistent','mean'),median_cycles_before_end=('cycles_before_end','median')).reset_index();summ.to_csv(os.path.join(R,'definitive_summary.csv'),index=False)
rec.groupby(['fd','method']).agg(engines=('engine','count'),early_raw=('early_raw','mean'),late_raw=('late_raw','mean'),late_persistent=('late_persistent','mean'),final_persistent=('final_persistent','mean')).reset_index().to_csv(os.path.join(R,'definitive_by_fd.csv'),index=False)
base=rec[rec.method=='ASHI_original'].sort_values(['fd','engine']).reset_index(drop=True);ci=[];rr=np.random.default_rng(29)
for method in methods:
 other=rec[rec.method==method].sort_values(['fd','engine']).reset_index(drop=True)
 assert np.array_equal(base[['fd','engine']].values,other[['fd','engine']].values)
 for metric in ['late_persistent','early_raw','final_persistent']:
  dif=(base[metric]-other[metric]).to_numpy();boot=np.mean(dif[rr.integers(0,len(dif),size=(2500,len(dif)))],axis=1)
  ci.append(dict(comparator=method,metric=metric,difference=float(dif.mean()),ci95_low=float(np.quantile(boot,.025)),ci95_high=float(np.quantile(boot,.975))))
pd.DataFrame(ci).to_csv(os.path.join(R,'definitive_paired_ci.csv'),index=False)
with open(os.path.join(R,'definitive_protocol.json'),'w') as f:json.dump({'kernel':'original compiled C','input':'log1p sensor reference standardized RMS, regime-adjusted, calibrated on first 25 cycles of training engines','split':'50/50 by engine per FD; seed 20261108','matched':'baseline raw early positive rate matched to ASHI in calibration, pooled per FD','persistence':'10 of trailing 15 cycles','warning':'test early false alarm rates NOT equal exactly; no actual onset labels; late persistent is not accuracy','diagnostics':diagnostics},f,indent=2)
print(summ.to_string(index=False))
