import numpy as np,pandas as pd, json, pathlib, time, zipfile, shutil
from sklearn.metrics import roc_auc_score, average_precision_score
root=pathlib.Path('/mnt/data/ASHI_comparative_audit');root.mkdir(exist_ok=True)
df=pd.read_csv('/mnt/data/ashi_eeg_benchmark/window_predictions.csv'); groups=[(k,g.sort_values('second')) for k,g in df.groupby(['subject','run'])]
subjects=sorted(df.subject.unique()); train=set(subjects[:6]); test=set(subjects[6:]); rng=np.random.default_rng(841)
# causal scores: previous-only online all-history z, rolling-30 z, EWMA z. ASHI uses current-inclusive running mean/std.
def scores(x):
 n=len(x);out=np.full((n,4),np.nan);m=0.;m2=0.;ema=0.;ev=0.
 for i,v in enumerate(x):
  if i>=5:
   s=np.sqrt(max(m2/(i-1),1e-12));out[i,0]=(v-m)/s
   prev=x[max(0,i-30):i];out[i,1]=(v-prev.mean())/max(prev.std(ddof=1),1e-6)
   out[i,2]=(v-ema)/max(np.sqrt(ev),1e-6)
  d=v-m;m+=d/(i+1);m2+=d*(v-m)
  if i==0:ema=v;ev=1e-4
  else:
   alpha=.1;d=v-ema;ema+=alpha*d;ev=(1-alpha)*(ev+alpha*d*d)
  if i>=4:
   out[i,3]=(v-m)/max(np.sqrt(m2/i),1e-6)
 return out
# original ASHI score is current inclusive z; flag >1.441, matching C except initial 5
clean={}; events={}; details=[]
for (sub,run),g in groups:
 x=g.log10_global_rms.to_numpy();base=scores(x);assert np.array_equal((base[:,3]>1.441).astype(int),g.ashi_flag.to_numpy())
 clean[sub,run]=base
 for mult in [1.5,2.,3.]:
  ix=np.arange(15,len(x)-2)
  if len(ix)<3:continue
  chosen=np.sort(rng.choice(ix,size=min(3,len(ix)),replace=False))
  y=x.copy();y[chosen]+=np.log10(mult)
  pert=scores(y)
  events[sub,run,mult]=(chosen,pert,base)
# thresholds chosen on first 6 subjects clean for 5% window false-alarm target
alltrain=np.vstack([s for (sub,_),s in clean.items() if sub in train]);thresholds=np.nanquantile(alltrain[:,:3],.95,axis=0).tolist()+[1.441]
models=['Causal global z','Causal rolling30 z','Causal EWMA z','ASHI C original']
rows=[];detail=[]
for model,thr,j in zip(models,thresholds,range(4)):
 for split,subs in [('calibration',train),('held_out',test)]:
  c=np.concatenate([a[:,j] for (sub,_),a in clean.items() if sub in subs]); c=c[np.isfinite(c)]
  for mult in [1.5,2.,3.]:
   positives=[]; incremental=[]; lat=[]
   for (sub,run,m),(idx,pert,base) in events.items():
    if sub not in subs or m!=mult:continue
    positives.extend((pert[idx,j]>thr).astype(int).tolist());incremental.extend(((pert[idx,j]>thr)&~(base[idx,j]>thr)).astype(int).tolist())
   rows.append(dict(model=model,threshold=thr,split=split,multiplier=mult,clean_n=len(c),clean_positive_rate=float(np.mean(c>thr)),injected_events=len(positives),event_detection_rate=float(np.mean(positives)),incremental_detection_rate=float(np.mean(incremental)),new_detected=int(sum(incremental))))
R=pd.DataFrame(rows);R.to_csv(root/'matched_baseline_comparison.csv',index=False)
# original ASHI rates by subject, subject-level bootstrap confidence interval on clean rate and incremental event sensitivity
subjectrows=[]
for sub in subjects:
 cc=np.concatenate([clean[sub,run][:,3] for (s,run) in clean if s==sub]);cc=cc[np.isfinite(cc)]
 for mult in [1.5,2.,3.]:
  det=[];inc=[]
  for (s,r,m),(ix,p,b) in events.items():
   if s==sub and m==mult:
    det.extend((p[ix,3]>1.441).tolist());inc.extend(((p[ix,3]>1.441)&~(b[ix,3]>1.441)).tolist())
  subjectrows.append(dict(subject=sub,multiplier=mult,clean_alarm_rate=float(np.mean(cc>1.441)),events=len(det),detected=sum(det),new_detected=sum(inc)))
S=pd.DataFrame(subjectrows);S.to_csv(root/'subject_level_metrics.csv',index=False)
# 95% subject bootstrap, heldout
rng=np.random.default_rng(442);cis=[]
for mult in [1.5,2.,3.]:
 q=S[(S.subject.isin(test))&(S.multiplier==mult)].reset_index(drop=True)
 samples=[]
 for _ in range(3000):
  a=q.iloc[rng.integers(0,len(q),len(q))];samples.append((a.new_detected.sum()/a.events.sum(),a.clean_alarm_rate.mean()))
 cis.append(dict(multiplier=mult,incremental_ci_low=float(np.quantile(np.array(samples)[:,0],.025)),incremental_ci_high=float(np.quantile(np.array(samples)[:,0],.975)),clean_alarm_ci_low=float(np.quantile(np.array(samples)[:,1],.025)),clean_alarm_ci_high=float(np.quantile(np.array(samples)[:,1],.975))))
pd.DataFrame(cis).to_csv(root/'subject_bootstrap_ci.csv',index=False)
# computational exact kernel C benchmark, pure C compiled command line
src=pathlib.Path('/mnt/data/ashicore_v210.c');shutil.copy(src,root/'ashicore_v210.c')
report={'dataset':'EEGMMIDB 12 subjects 36 recordings 4446 1-second windows, derived log10 global RMS','scope':'feature-level controlled injections, NOT physical sensor failures','split':{'train_subjects':sorted(train),'test_subjects':sorted(test)},'threshold_policy':'causal baseline thresholds calibrated on clean first six subjects to 5% false positive window rate; ASHI fixed Kc=1.441','thresholds':dict(zip(models,thresholds)),'original_replay':'verified original ASHI flags for all windows','held_out_results':R[R.split=='held_out'].to_dict('records'),'ci':cis,'limitations':['No verified fault labels; clean EEG includes natural motion artifacts','All tests use scalar feature-level perturbations, not physical channel noise','A 1-second RMS window imposes sensing latency','No inference about robotics safety, early warning, or clinical prediction','6 subjects per split; low statistical power','Calibrated methods and ASHI use different operating points; compare false-alarm rate alongside sensitivity']}
(root/'summary.json').write_text(json.dumps(report,indent=2))
print(R[R.split=='held_out'].to_string(index=False));print('CIs',cis)
# operating point matched to 5% on calibration subjects, including ASHI statistic
ashi_thr=float(np.nanquantile(alltrain[:,3],.95)); rows2=[]
for j,model in enumerate(models):
 thr=thresholds[j] if j<3 else ashi_thr
 for mult in [1.5,2.,3.]:
  det=[];inc=[]
  for (sub,run,m),(idx,pert,base) in events.items():
   if sub in test and m==mult:
    det.extend((pert[idx,j]>thr).tolist());inc.extend(((pert[idx,j]>thr)&~(base[idx,j]>thr)).tolist())
  cleanvals=np.concatenate([a[:,j] for (sub,_),a in clean.items() if sub in test]);cleanvals=cleanvals[np.isfinite(cleanvals)]
  rows2.append(dict(model=model,threshold=thr,multiplier=mult,clean_positive_rate=float(np.mean(cleanvals>thr)),detection_rate=np.mean(det),incremental_detection_rate=np.mean(inc),events=len(det)))
M=pd.DataFrame(rows2);M.to_csv(root/'equal_calibration_alarm_comparison.csv',index=False)
print('EQUAL FPR',M.to_string(index=False))
