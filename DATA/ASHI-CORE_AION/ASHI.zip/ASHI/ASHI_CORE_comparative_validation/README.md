# ASHI-CORE v2.1.0 — Comparative Sensory Watchdog Audit

## Scope
A controlled feature-level perturbation experiment using 4,446 one-second log10(global RMS) windows derived from real PhysioNet EEGMMIDB recordings, 12 subjects, 36 runs. This **does not** validate robotic safety, pre-ictal warning, or physical sensor fault detection.

## Protocol
Subjects S001–S006 used for calibration, S007–S012 held out. Each recording is a causal independent stream. Synthetic amplitude multipliers 1.5x, 2x and 3x were injected into three selected scalar-feature windows per recording (54 events per amplitude on the held-out subjects). Clean EEG windows are not verified fault-free, so clean alarm rate is only a surrogate false-alarm rate.

Original ASHI-CORE C algorithm was replay-verified against stored flags. Comparison implementations compute mathematically corresponding ASHI running z score and three conventional *causal* z-score alternatives. The original C kernel's decision rule is Kc=1.441. Comparison uses two views:

1. **Original fixed operating point** (Kc=1.441): ASHI flags 7.17% of clean held-out windows, with 79.63% *new* detections of 2x impulses. Global causal z baseline flags 2.54% of clean windows and detects 62.96% of 2x impulses. This is NOT a fair same-FPR comparison.
2. **Calibration-matched nominal 5% clean alarm rate**: comparison of score thresholded at train 95th percentile. This is a *diagnostic threshold change* (ASHI threshold becomes 1.890903) and is NOT the unmodified ASHI C binary output. On held-out subjects ASHI score detects 64.81% of 2x injections with 3.03% clean positives, versus global causal z 62.96% with 2.54% clean positives. There is no demonstrated meaningful advantage.

The ASHI score uses the **current sample in its running mean and standard deviation**; other baselines are prior-only. This structural difference should not be interpreted as novel predictive information.

## Data limitations
- EEGMMIDB is motor EEG, not epileptic seizure data; no pre-ictal horizon is defined.
- Perturbations were applied to a scalar feature, not the EDF samples or individual channels. No sensor-noise physics or channel masking is assessed in this comparison.
- The 12-subject sample is small, and injected events within subjects are correlated. Subject-bootstrap intervals are exploratory.
- No robot hardware, end-to-end latency, FLOPs, or physical fault labels.
- The source 4,446-window CSV must be provided to reproduce; it is included in this archive.

## Files
- `reproduce_comparison.py`: complete reproduction of comparison, expects source CSV at its original `/mnt/data/ashi_eeg_benchmark/window_predictions.csv` path (edit for your system).
- `window_predictions.csv`: 4,446 original derived windows.
- `ashicore_v210.c`: original C source.
- `matched_baseline_comparison.csv`: fixed ASHI vs calibrated baseline thresholds.
- `equal_calibration_alarm_comparison.csv`: calibration-matched score thresholds.
- `subject_level_metrics.csv`: original kernel results by subject.
- `subject_bootstrap_ci.csv`: exploratory subject-level bootstrap intervals.
- `summary.json`: machine-readable experiment metadata.
