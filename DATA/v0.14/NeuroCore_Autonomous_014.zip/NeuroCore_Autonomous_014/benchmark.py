import ctypes, subprocess, pathlib, numpy as np, csv
ROOT=pathlib.Path(__file__).parent
subprocess.run(['gcc','-std=c11','-O3','-fPIC','-shared',str(ROOT/'neurocore.c'),'-lm','-o',str(ROOT/'libnc.so')],check=True)
lib=ctypes.CDLL(str(ROOT/'libnc.so'));lib.nc_bytes.restype=ctypes.c_size_t
lib.nc_init.argtypes=[ctypes.c_void_p];lib.nc_step.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_float),ctypes.c_int,ctypes.POINTER(ctypes.c_float)]
D=4; N=1200
# independent random seeds; all hyperparameters frozen before evaluation
rows=[]
for scenario in ['smooth','outliers','switch','drift','dropout']:
 for seed in range(40):
  rng=np.random.default_rng(5000+seed)
  centers=np.array([[0,0,0,0],[1.0,-.7,.8,-.6],[-.8,.9,-.7,1.0]],float)
  truth=np.zeros((N,D)); mode=0
  for t in range(N):
   if scenario in ['switch','outliers','dropout'] and t in [220,420,620,820,1020]:mode=[1,2,0,2,0][[220,420,620,820,1020].index(t)]
   target=centers[mode].copy()
   if scenario=='drift':target+=0.00045*t*np.array([1,-1,.7,-.7])
   if scenario=='smooth':target+=0.3*np.sin(t/90)*np.array([1,.5,-.4,.2])
   if t:truth[t]=.96*truth[t-1]+.04*target
  obs=truth+rng.normal(0,.17,(N,D))

  if scenario=='outliers':
   idx=rng.choice(np.arange(50,N),int(.06*N),replace=False);obs[idx]+=rng.normal(0,2.0,(len(idx),D))
  if scenario=='dropout':
   for a in [290,710,960]:obs[a:a+18]+=rng.normal(0,1.2,(18,D))
  mem=ctypes.create_string_buffer(lib.nc_bytes());lib.nc_init(mem)
  out=np.zeros((N,D)); ema=np.zeros((N,D)); adaptive=np.zeros((N,D)); kalman=np.zeros((N,D))
  P=np.ones(D)*0.3; Q=.0005;R=.17**2
  for t in range(N):
   inp=(ctypes.c_float*D)(*obs[t].astype('float32'));ret=(ctypes.c_float*(D+4))()
   lib.nc_step(mem,inp,D,ret)
   out[t]=[ret[j] for j in range(D)]
   if t==0:ema[t]=obs[t];adaptive[t]=obs[t];kalman[t]=obs[t]
   else:
    ema[t]=ema[t-1]+.10*(obs[t]-ema[t-1])
    innov=np.mean((obs[t]-adaptive[t-1])**2)
    g=.19/(1+innov/(4*(.015+R)))
    adaptive[t]=adaptive[t-1]+g*(obs[t]-adaptive[t-1])
    P+=Q;K=P/(P+R);kalman[t]=kalman[t-1]+K*(obs[t]-kalman[t-1]);P=(1-K)*P
  for name,estimate in [('NeuroCore',out),('EMA',ema),('adaptive_EMA',adaptive),('Kalman_RW',kalman)]:
   rmse=np.sqrt(np.mean((estimate[100:]-truth[100:])**2))
   rows.append(dict(scenario=scenario,seed=seed,method=name,rmse=rmse))
with (ROOT/'results.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
for s in ['smooth','outliers','switch','drift','dropout']:
 print(s,' '.join(f'{m}={np.mean([r["rmse"] for r in rows if r["scenario"]==s and r["method"]==m]):.4f}' for m in ['NeuroCore','EMA','adaptive_EMA','Kalman_RW']))
print('kernel_bytes',lib.nc_bytes())
