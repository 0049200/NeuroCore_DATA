# NeuroCore v0.14 — Directional innovation (exploratory)

C11 causal bounded-memory functional-state observer. `nc_step(NC*, const float*, int, float*)` accepts no oracle `quality` input. Compile: `gcc -std=c11 -O3 -Wall -Wextra -fPIC -shared neurocore.c -lm -o libnc.so`. Run: `python benchmark.py` (requires NumPy and gcc). The script compiles the C source and produces `results.csv`.

## Change from v0.13

Added an exponentially smoothed *signed innovation vector* (`directional[8]`) and a coherence ratio. Only for small innovations (`e2 < 0.12`) with sufficient directional coherence (`>0.08`) does the gain increase. Memory and anchor consolidation are otherwise unchanged. Structure size on the tested platform: 280 bytes (v0.13: 244 bytes). No heap allocation per step.

## Results and caveats

Synthetic test: 5 scenarios × 40 seeds × 1200 time points, RMSE after first 100 samples; four methods per seed. See `results.csv`. v0.14 vs v0.13 mean RMSE: smooth 0.057164 vs 0.057162; outliers 0.067576 vs 0.067592; switch 0.064389 vs 0.066526; drift 0.056767 vs 0.056775; dropout 0.071853 vs 0.072826. In switch and dropout, 39/40 seeds improved. The main target, drift, did not meaningfully improve. The `dropout` scenario simulates corrupted observations, **not missing observations**. All methods receive the same observations; baselines are simple and not tuned robust filters.

**IMPORTANT: Exploratory test, not held-out validation.** The first candidate was tested on these seeds and failed; the gate was then modified and re-tested on the *same seeds*. Thus this is a development result, not evidence of out-of-sample superiority. New seeds, robust Kalman, properly tuned EMA, ablation and real data are needed. Directional memory costs 36 additional bytes, so its incremental benefit must justify the overhead.

## Files

- `neurocore.c`: modified C11 kernel.
- `neurocore_v013.c`: original reference kernel.
- `benchmark.py`: reproducible simulation and baselines.
- `results.csv`: full individual results.
