/* NeuroCore continuous functional state observer — experimental C11, MIT-style research prototype.
 * One step, no heap allocation, fixed bounded memory. Features are supplied by domain adapter.
 */
#include <math.h>
#include <string.h>
#include <stddef.h>
#define NC_D 8
#define NC_K 4
typedef struct {
 float z[NC_D], velocity[NC_D], anchors[NC_K][NC_D];
 float count[NC_K], residual_ema, confidence, last_novelty, innovation_ema, persistence;
 float directional[NC_D], directional_energy;
 int initialized, used, last_match, stable_count;
} NC;
void nc_init(NC *s){memset(s,0,sizeof(*s));s->last_match=-1;}
static float sqdist(const float*a,const float*b,int d){float r=0;for(int i=0;i<d;i++){float v=a[i]-b[i];r+=v*v;}return r/d;}
/* Autonomous: no external quality, dim 1..8. Output: state estimate, novelty, matched anchor, confidence.
 * No training labels; memory consolidation only on sustained, low-innovation observations.
 */
void nc_step(NC*s,const float*x,int dim,float*out){
 if(dim<1||dim>NC_D)return;

 if(!s->initialized){for(int j=0;j<dim;j++)s->z[j]=x[j];s->initialized=1;s->confidence=1.f;}
 float pred[NC_D], e2=0;
 for(int j=0;j<dim;j++){pred[j]=s->z[j]+0.55f*s->velocity[j];float e=x[j]-pred[j];e2+=e*e;}
 e2/=dim;
 /* Self-estimated reliability: transient innovations downweighted, persistent shifts accepted.
    All terms computed causally from x and previous internal state. */
 float noise=fmaxf(s->residual_ema,0.015f);
 float shock=e2/(noise+0.03f);
 float quality=1.f/(1.f+0.16f*shock);
 s->persistence=0.92f*s->persistence+0.08f*fminf(shock,10.f);
 if(s->persistence>2.0f)quality=fmaxf(quality,0.60f);
 s->innovation_ema=0.97f*s->innovation_ema+0.03f*fminf(e2,4.f);
 float best=1e30f;int kbest=-1;
 for(int k=0;k<s->used;k++){float d=sqdist(x,s->anchors[k],dim);if(d<best){best=d;kbest=k;}}
 /* innovation gate: robust to transient outliers; a confirmed old anchor supports reacquisition */
 noise=s->residual_ema+0.015f;
 /* Detect coherent persistent innovations: a gradual displacement has a sustained
    signed residual; zero-mean impulses do not. Causal, bounded, no oracle quality. */
 float dir2=0.f;
 for(int j=0;j<dim;j++){
   float e=x[j]-pred[j];
   s->directional[j]=0.94f*s->directional[j]+0.06f*e;
   dir2+=s->directional[j]*s->directional[j];
 }
 dir2/=dim;
 float coherence=dir2/(s->innovation_ema+0.012f);
 if(coherence>1.f)coherence=1.f;
 if(coherence<0.f)coherence=0.f;
 float gain=0.19f*quality/(1.f+e2/(4.f*noise));
 /* Allow persistent innovations to override transient shock rejection. */
 if(e2<0.12f && coherence>0.08f){
   float drift_gain=0.19f+0.15f*coherence;
   if(drift_gain>gain)gain=drift_gain;
 }
 int recalled=(kbest>=0 && best<0.055f && e2>0.06f);
 if(recalled)gain=fmaxf(gain,0.32f*quality);
 gain=0.19f;
 for(int j=0;j<dim;j++){
   float previous=s->z[j];
   s->z[j]=pred[j]+gain*(x[j]-pred[j]);
   s->velocity[j]=0.82f*s->velocity[j]+0.18f*(s->z[j]-previous);
 }
 float residual=sqdist(x,s->z,dim);
 s->residual_ema=0.98f*s->residual_ema+0.02f*fminf(residual,1.0f);
 s->confidence=0.94f*s->confidence+0.06f*quality/(1.f+residual);
 s->last_novelty=(kbest<0)?1.f:sqrtf(best);
 s->last_match=(best<0.055f)?kbest:-1;
 /* consolidation of stable states; no replacement of old anchors, bounded memory */
 if(quality>0.8f && e2<0.045f)s->stable_count++;else s->stable_count=0;
 if(s->stable_count>=12){
   if(kbest<0 || best>0.09f){if(s->used<NC_K){memcpy(s->anchors[s->used],s->z,dim*sizeof(float));s->count[s->used]=1;s->used++;}}
   else if(best<0.035f){float alpha=0.002f;for(int j=0;j<dim;j++)s->anchors[kbest][j]=(1-alpha)*s->anchors[kbest][j]+alpha*s->z[j];s->count[kbest]++;}
   s->stable_count=0;
 }
 for(int j=0;j<dim;j++)out[j]=s->z[j];
 out[dim]=s->last_novelty;out[dim+1]=(float)s->last_match;out[dim+2]=s->confidence;out[dim+3]=(float)s->used;
}
size_t nc_bytes(void){return sizeof(NC);}
