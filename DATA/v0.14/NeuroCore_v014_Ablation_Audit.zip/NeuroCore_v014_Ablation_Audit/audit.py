import ctypes,subprocess,pathlib,numpy as np,csv
P=pathlib.Path(__file__).parent; src=(P/'neurocore.c').read_text()
variants={
 'full':src,
 'no_memory':src.replace('int recalled=(kbest>=0 && best<0.055f && e2>0.06f);','int recalled=0;').replace('if(s->stable_count>=12){','if(0 && s->stable_count>=12){'),
 'no_directional':src.replace('if(e2<0.12f && coherence>0.08f){','if(0 && e2<0.12f && coherence>0.08f){'),
 'fixed_gain':src.replace('if(recalled)gain=fmaxf(gain,0.32f*quality);','if(recalled)gain=fmaxf(gain,0.32f*quality);\n gain=0.19f;'),
 'no_velocity':src.replace('pred[j]=s->z[j]+0.55f*s->velocity[j]','pred[j]=s->z[j]'),
}
libs={}
for name,code in variants.items():
 path=P/f'{name}.c';path.write_text(code);so=P/f'{name}.so'
 subprocess.run(['gcc','-std=c11','-O2','-fPIC','-shared',str(path),'-lm','-o',str(so)],check=True)
 l=ctypes.CDLL(str(so));l.nc_bytes.restype=ctypes.c_size_t;l.nc_init.argtypes=[ctypes.c_void_p];l.nc_step.argtypes=[ctypes.c_void_p,ctypes.POINTER(ctypes.c_float),ctypes.c_int,ctypes.POINTER(ctypes.c_float)];libs[name]=l
D=4;N=1200;rows=[]; telemetry=[]
for scenario in ['smooth','outliers','switch','drift','dropout']:
 for seed in range(40):
  rng=np.random.default_rng(19000+seed)
  centers=np.array([[0,0,0,0],[1,-.7,.8,-.6],[-.8,.9,-.7,1.0]],float)
  truth=np.zeros((N,D));mode=0
  for t in range(N):
   if scenario in ['switch','outliers','dropout'] and t in [220,420,620,820,1020]:mode=[1,2,0,2,0][[220,420,620,820,1020].index(t)]
   target=centers[mode].copy()
   if scenario=='drift':target+=.00045*t*np.array([1,-1,.7,-.7])
   if scenario=='smooth':target+=.3*np.sin(t/90)*np.array([1,.5,-.4,.2])
   if t:truth[t]=.96*truth[t-1]+.04*target
  obs=truth+rng.normal(0,.17,(N,D))
  if scenario=='outliers':
   idx=rng.choice(np.arange(50,N),int(.06*N),replace=False);obs[idx]+=rng.normal(0,2,(len(idx),D))
  if scenario=='dropout':
   for a in [290,710,960]:obs[a:a+18]+=rng.normal(0,1.2,(18,D))
  for name,l in libs.items():
   mem=ctypes.create_string_buffer(l.nc_bytes());l.nc_init(mem);est=np.zeros((N,D));used=[];matches=[]
   for t in range(N):
    inp=(ctypes.c_float*D)(*obs[t].astype('float32'));ret=(ctypes.c_float*(D+4))();l.nc_step(mem,inp,D,ret)
    est[t]=[ret[j] for j in range(D)];used.append(ret[D+3]);matches.append(ret[D+1])
   rmse=float(np.sqrt(np.mean((est[100:]-truth[100:])**2)))
   rows.append(dict(scenario=scenario,seed=seed,variant=name,rmse=rmse,anchors_final=int(used[-1]),match_fraction=float(np.mean(np.array(matches)>=0))))
with (P/'ablation_results.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
for scenario in ['smooth','outliers','switch','drift','dropout']:
 print(scenario, ' '.join(f'{v}:{np.mean([r["rmse"] for r in rows if r["scenario"]==scenario and r["variant"]==v]):.5f}' for v in variants))
print('memory diagnostics',[(s,round(np.mean([r['anchors_final'] for r in rows if r['scenario']==s and r['variant']=='full']),2),round(np.mean([r['match_fraction'] for r in rows if r['scenario']==s and r['variant']=='full']),3)) for s in ['smooth','outliers','switch','drift','dropout']]);print('bytes',libs['full'].nc_bytes())
